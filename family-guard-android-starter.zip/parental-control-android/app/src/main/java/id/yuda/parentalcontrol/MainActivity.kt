package id.yuda.parentalcontrol

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Timelapse
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FamilyGuardApp() }
    }
}

private enum class Page { HOME, PARENT, CHILD, LIMITS, SCHEDULE, REPORTS, LOCATION, BLOCKING }

@Composable
private fun FamilyGuardApp() {
    var page by remember { mutableStateOf(Page.HOME) }
    var childName by remember { mutableStateOf("Perangkat anak") }
    var dailyLimit by remember { mutableStateOf(180f) }
    var studyStart by remember { mutableStateOf("16:00") }
    var studyEnd by remember { mutableStateOf("18:00") }
    var sleepStart by remember { mutableStateOf("21:00") }
    var sleepEnd by remember { mutableStateOf("06:00") }
    var selectedApps by remember { mutableStateOf(setOf("TikTok", "Instagram")) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF176B5B),
            background = androidx.compose.ui.graphics.Color(0xFFF6F8F7),
            surface = androidx.compose.ui.graphics.Color(0xFFFFFFFF)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBarSimple(
                    title = when (page) {
                        Page.HOME -> "Family Guard"
                        Page.PARENT -> "Mode Orang Tua"
                        Page.CHILD -> "Mode Anak"
                        Page.LIMITS -> "Batas Waktu"
                        Page.SCHEDULE -> "Jadwal"
                        Page.REPORTS -> "Laporan Penggunaan"
                        Page.LOCATION -> "Lokasi Perangkat"
                        Page.BLOCKING -> "Aplikasi Dibatasi"
                    },
                    back = if (page == Page.HOME) null else ({ page = Page.HOME })
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize()
                    .verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (page) {
                    Page.HOME -> {
                        Text("Kontrol keluarga, dengan aturan yang jelas.", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Pilih peran untuk melihat prototipe antarmuka. Fitur pemantauan jarak jauh belum aktif sampai backend dan izin perangkat dikonfigurasi.")
                        ModeCard("Orang tua", "Atur batas, jadwal, dan lihat status perangkat.", Icons.Default.Security) { page = Page.PARENT }
                        ModeCard("Anak", "Lihat aturan yang diterapkan dan status pemasangan.", Icons.Default.ChildCare) { page = Page.CHILD }
                        InfoCard("Status proyek", "Prototipe UI v0.1 • Belum terhubung ke server • Belum memblokir aplikasi")
                    }
                    Page.PARENT -> {
                        Text("Perangkat terhubung", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        OutlinedTextField(value = childName, onValueChange = { childName = it }, label = { Text("Nama perangkat anak") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        InfoCard("Belum dipasangkan", "Pemasangan jarak jauh memerlukan autentikasi dan backend. Jangan gunakan kode pairing yang mudah ditebak.")
                        ModeCard("Batas waktu aplikasi", "Atur batas pemakaian harian.", Icons.Default.Timelapse) { page = Page.LIMITS }
                        ModeCard("Jadwal belajar & tidur", "Tentukan jam aturan aktif.", Icons.Default.Schedule) { page = Page.SCHEDULE }
                        ModeCard("Aplikasi yang dibatasi", "Pilih aplikasi untuk kebijakan pembatasan.", Icons.Default.Devices) { page = Page.BLOCKING }
                        ModeCard("Laporan penggunaan", "Ringkasan penggunaan perlu izin Usage Access.", Icons.Default.NotificationsActive) { page = Page.REPORTS }
                        ModeCard("Lokasi perangkat", "Lokasi hanya tersedia setelah izin diberikan.", Icons.Default.LocationOn) { page = Page.LOCATION }
                    }
                    Page.CHILD -> {
                        Text("Perangkat anak", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        InfoCard("Pemasangan belum selesai", "Versi ini belum menerima aturan dari server. Langkah berikutnya adalah memasangkan perangkat dengan persetujuan pengguna dan sinkronisasi terenkripsi.")
                        InfoCard("Aturan contoh", "Batas harian: ${dailyLimit.toInt()} menit\nBelajar: $studyStart–$studyEnd\nTidur: $sleepStart–$sleepEnd")
                    }
                    Page.LIMITS -> {
                        Text("Batas penggunaan harian", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("${dailyLimit.toInt()} menit per hari (${dailyLimit.toInt() / 60} jam ${dailyLimit.toInt() % 60} menit)")
                        Slider(value = dailyLimit, onValueChange = { dailyLimit = it }, valueRange = 30f..360f, steps = 10)
                        Text("Batas per aplikasi harus ditambahkan pada tahap implementasi UsageStatsManager dan layanan penegakan aturan.")
                    }
                    Page.SCHEDULE -> {
                        Text("Jadwal contoh", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        OutlinedTextField(value = studyStart, onValueChange = { studyStart = it }, label = { Text("Mulai belajar (HH:mm)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = studyEnd, onValueChange = { studyEnd = it }, label = { Text("Selesai belajar (HH:mm)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = sleepStart, onValueChange = { sleepStart = it }, label = { Text("Mulai jadwal tidur (HH:mm)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = sleepEnd, onValueChange = { sleepEnd = it }, label = { Text("Selesai jadwal tidur (HH:mm)") }, modifier = Modifier.fillMaxWidth())
                        Text("Saat ini nilai hanya disimpan selama aplikasi terbuka; penyimpanan permanen dan sinkronisasi server belum dibuat.")
                    }
                    Page.BLOCKING -> {
                        Text("Pilih aplikasi untuk dibatasi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        listOf("TikTok", "Instagram", "YouTube", "Game", "Browser").forEach { app ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = selectedApps.contains(app), onCheckedChange = { checked ->
                                    selectedApps = if (checked) selectedApps + app else selectedApps - app
                                })
                                Text(app)
                            }
                        }
                        InfoCard("Catatan", "Pilihan ini masih berupa rancangan aturan. Pemblokiran nyata memerlukan mekanisme Android yang transparan dan izin pengguna atau perangkat terkelola.")
                    }
                    Page.REPORTS -> {
                        InfoCard("Laporan belum tersedia", "Belum ada data penggunaan yang dibaca dari perangkat. Android memerlukan pengguna mengaktifkan Usage Access di pengaturan.")
                        Text("Tahap berikutnya: membaca UsageStatsManager, menghitung durasi per paket aplikasi, lalu menyinkronkan ringkasan ke server.")
                    }
                    Page.LOCATION -> {
                        InfoCard("Lokasi belum dibaca", "Fitur lokasi membutuhkan izin lokasi di perangkat anak, penjelasan yang jelas, dan persetujuan pengguna. Pembaruan latar belakang dibatasi oleh Android.")
                        Text("Tahap berikutnya: permintaan izin saat pemasangan, pengambilan lokasi seperlunya, dan pengiriman lokasi terenkripsi ke akun orang tua yang dipasangkan.")
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Family Guard • Prototipe awal", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopAppBarSimple(title: String, back: (() -> Unit)?) {
    TopAppBar(
        title = { Text(title, fontWeight = FontWeight.SemiBold) },
        navigationIcon = {
            if (back != null) IconButton(onClick = back) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
            }
        }
    )
}

@Composable
private fun ModeCard(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(body, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
