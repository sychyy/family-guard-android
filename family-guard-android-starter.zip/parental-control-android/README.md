# Family Guard — Android parental control prototype

Versi: 0.1.0 (UI prototype)

## Yang tersedia pada starter ini
- Satu aplikasi Android dengan pilihan tampilan Mode Orang Tua dan Mode Anak.
- UI pengaturan batas waktu, jadwal belajar/tidur, daftar aplikasi yang akan dibatasi.
- Halaman status laporan dan lokasi yang menjelaskan izin yang dibutuhkan.
- Struktur proyek Kotlin + Jetpack Compose untuk dibuka di Android Studio.

## Yang BELUM aktif
Ini belum merupakan parental-control yang berfungsi penuh. Belum ada:
- autentikasi orang tua / anak dan pairing aman;
- server dan sinkronisasi aturan lintas perangkat;
- pembacaan UsageStatsManager;
- penegakan batas waktu / pemblokiran aplikasi;
- pengambilan lokasi atau pengiriman notifikasi;
- penyimpanan permanen aturan.

Jangan menganggap UI sebagai bukti bahwa fitur tersebut sudah berjalan.

## Membuka proyek
1. Pasang Android Studio versi stabil dan Android SDK Platform 35.
2. Ekstrak ZIP.
3. Buka folder `parental-control-android` di Android Studio.
4. Tunggu Gradle sync selesai.
5. Jalankan pada emulator atau HP Android untuk memeriksa UI.

## Membuat APK debug
Di Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

Alternatif terminal, jika Gradle tersedia:
`gradle assembleDebug`

Proyek ini tidak menyertakan Gradle Wrapper karena wrapper JAR perlu dihasilkan/diambil melalui instalasi Gradle.

## Arsitektur tahap berikutnya
- Android app: Kotlin, Jetpack Compose, UsageStatsManager, WorkManager, Fused Location Provider.
- Backend: Firebase Authentication + Cloud Firestore + Firebase Cloud Messaging (atau backend setara).
- Pairing: kode sekali pakai dengan kedaluwarsa, autentikasi kedua perangkat, aturan Firestore yang ketat.
- Privasi: indikator fitur aktif, pengumpulan data minimal, akses lokasi transparan, dan mekanisme melepas perangkat.

## Catatan pembatasan Android
- `PACKAGE_USAGE_STATS` bukan izin biasa; pengguna perlu mengaktifkan Usage Access dari Settings.
- Lokasi latar belakang perlu izin khusus pada versi Android yang relevan dan dapat dibatasi sistem/penghemat baterai.
- `AccessibilityService` hanya boleh digunakan untuk tujuan yang sesuai, harus diaktifkan pengguna, dan tidak boleh dipakai sebagai cara tersembunyi untuk memata-matai.
- Kontrol kuat lintas aplikasi membutuhkan perangkat terkelola/Device Policy Controller yang sah. API Android Enterprise bukan jalan pintas untuk aplikasi pribadi biasa; ada persyaratan kelayakan dan kebijakan layanan.
